package com.livetrader

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View
import java.util.Locale

/** Полоска «зелёное против красного»: доля лонгов и шортов, покупателей и продавцов. */
class BarView(ctx: Context) : View(ctx) {
    var frac: Double = -1.0          // доля зелёной части, меньше 0 = нет данных
    var leftLabel: String = "Лонги"
    var rightLabel: String = "Шорты"

    private val green = Paint()
    private val red = Paint()
    private val grey = Paint()
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        green.color = 0xFF2E8B57.toInt()
        red.color = 0xFFC0392B.toInt()
        grey.color = 0xFF555555.toInt()
        txt.color = 0xFFFFFFFF.toInt()
        txt.textSize = 13f * resources.displayMetrics.density
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w = width.toFloat()
        val h = height.toFloat()
        val base = h / 2f - (txt.descent() + txt.ascent()) / 2f
        val pad = 8f * resources.displayMetrics.density
        if (frac < 0.0) {
            c.drawRect(0f, 0f, w, h, grey)
            txt.textAlign = Paint.Align.LEFT
            c.drawText("нет данных", pad, base, txt)
            return
        }
        val gw = (w * frac).toFloat()
        c.drawRect(0f, 0f, gw, h, green)
        c.drawRect(gw, 0f, w, h, red)
        txt.textAlign = Paint.Align.LEFT
        c.drawText(leftLabel + " " + String.format(Locale.US, "%.0f", frac * 100.0) + "%", pad, base, txt)
        txt.textAlign = Paint.Align.RIGHT
        c.drawText(rightLabel + " " + String.format(Locale.US, "%.0f", (1.0 - frac) * 100.0) + "%", w - pad, base, txt)
    }
}
