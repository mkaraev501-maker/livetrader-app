package com.livetrader

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.Image
import android.media.ImageReader
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.util.Base64
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.Locale
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

/**
 * Держит сессию Gemini Live: микрофон + кадры экрана уходят в модель,
 * голос модели проигрывается в динамик.
 */
class LiveService : Service() {

    private data class Attempt(val model: String, val transcribe: Boolean, val tools: Boolean)

    // Порядок попыток: если первая модель недоступна, берётся следующая.
    private val attempts = listOf(
        Attempt("gemini-3.8-live", true, true),
        Attempt("gemini-3.1-flash-live-preview", true, true),
        Attempt("gemini-2.5-flash-native-audio-preview-12-2025", true, true),
        Attempt("gemini-3.8-live", false, false),
        Attempt("gemini-3.1-flash-live-preview", false, false),
    )

    private val frameIntervalMs = 1500L   // как часто отправлять кадр экрана
    private val frameWidth = 540          // ширина кадра (меньше = легче для слабого телефона)

    private val main = Handler(Looper.getMainLooper())
    private val client = OkHttpClient.Builder()
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .pingInterval(20, TimeUnit.SECONDS)
        .build()

    private var apiKey = ""
    @Volatile private var active = false
    @Volatile private var ready = false
    @Volatile private var generation = 0
    private var attemptIdx = 0
    private var fails = 0
    private var ws: WebSocket? = null

    private var projection: MediaProjection? = null
    private var vDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var imgThread: HandlerThread? = null
    @Volatile private var lastFrame = 0L
    private var frameErrLogged = false

    private var rec: AudioRecord? = null
    private var micThread: Thread? = null

    private var track: AudioTrack? = null
    private var playThread: Thread? = null
    private val playQueue = LinkedBlockingQueue<ByteArray>()

    private var speaker = ""

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        apiKey = intent.getStringExtra("key") ?: ""
        val code = intent.getIntExtra("code", 0)
        @Suppress("DEPRECATION")
        val data: Intent? = intent.getParcelableExtra("data")
        if (data == null || apiKey.isEmpty()) {
            stopSelf()
            return START_NOT_STICKY
        }

        startAsForeground()
        active = true
        Bus.running = true
        try {
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val p = mpm.getMediaProjection(code, data)
            projection = p
            p.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    if (active) {
                        Bus.line("Запись экрана остановлена системой.")
                        stopSelf()
                    }
                }
            }, main)
            startCapture(p)
            startPlayback()
            startMic()
            connect()
            Bus.postStatus("Подключаюсь...")
            Bus.line("Старт. Открой график и говори.")
        } catch (e: Exception) {
            Bus.line("Ошибка запуска: ${e.message}")
            Bus.postStatus("Ошибка")
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("live", "Live Трейдер", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, "live")
            .setContentTitle("Live Трейдер работает")
            .setContentText("Видит экран и слушает микрофон")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            val type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION or
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            startForeground(1, n, type)
        } else {
            startForeground(1, n)
        }
    }

    // ---------------- Экран ----------------

    private fun startCapture(p: MediaProjection) {
        val dm = resources.displayMetrics
        val w = frameWidth
        val h = (dm.heightPixels.toFloat() * w / dm.widthPixels).toInt()
        val thread = HandlerThread("frames")
        thread.start()
        imgThread = thread

        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        reader = r
        r.setOnImageAvailableListener({ ir ->
            var img: Image? = null
            try {
                img = ir.acquireLatestImage()
                if (img != null) {
                    val now = System.currentTimeMillis()
                    if (ready && now - lastFrame >= frameIntervalMs) {
                        lastFrame = now
                        sendFrame(img)
                    }
                }
            } catch (e: Exception) {
                if (!frameErrLogged) {
                    frameErrLogged = true
                    Bus.line("Кадр экрана не прочитан: " + e.message)
                }
            } finally {
                img?.close()
            }
        }, Handler(thread.looper))

        vDisplay = p.createVirtualDisplay(
            "live", w, h, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            r.surface, null, null
        )
    }

    private fun sendFrame(img: Image) {
        val plane = img.planes[0]
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val fullW = rowStride / pixelStride
        val bmp = Bitmap.createBitmap(fullW, img.height, Bitmap.Config.ARGB_8888)
        bmp.copyPixelsFromBuffer(plane.buffer)
        val cropped = if (fullW != img.width) Bitmap.createBitmap(bmp, 0, 0, img.width, img.height) else bmp
        val out = ByteArrayOutputStream()
        cropped.compress(Bitmap.CompressFormat.JPEG, 60, out)
        if (cropped !== bmp) cropped.recycle()
        bmp.recycle()
        val b64 = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
        ws?.send("{\"realtimeInput\":{\"video\":{\"data\":\"$b64\",\"mimeType\":\"image/jpeg\"}}}")
    }

    // ---------------- Микрофон ----------------

    @SuppressLint("MissingPermission")
    private fun startMic() {
        val min = AudioRecord.getMinBufferSize(
            16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val r = AudioRecord(
            MediaRecorder.AudioSource.VOICE_COMMUNICATION, 16000,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
            maxOf(min, 6400)
        )
        rec = r
        r.startRecording()
        val t = Thread {
            val buf = ByteArray(3200) // 100 мс звука
            while (active) {
                val n = r.read(buf, 0, buf.size)
                if (n > 0 && ready) {
                    val b64 = Base64.encodeToString(buf, 0, n, Base64.NO_WRAP)
                    ws?.send("{\"realtimeInput\":{\"audio\":{\"data\":\"$b64\",\"mimeType\":\"audio/pcm;rate=16000\"}}}")
                }
            }
        }
        micThread = t
        t.start()
    }

    // ---------------- Звук ответа ----------------

    private fun startPlayback() {
        val min = AudioTrack.getMinBufferSize(
            24000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(24000)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(maxOf(min, 24000))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        track = t
        t.play()
        val th = Thread {
            while (active) {
                val chunk = playQueue.poll(200, TimeUnit.MILLISECONDS) ?: continue
                try {
                    t.write(chunk, 0, chunk.size)
                } catch (e: Exception) {
                    // трек остановлен
                }
            }
        }
        playThread = th
        th.start()
    }

    private fun flushPlayback() {
        playQueue.clear()
        val t = track ?: return
        try {
            t.pause()
            t.flush()
            t.play()
        } catch (e: Exception) {
            // ничего
        }
    }

    // ---------------- Связь с Gemini Live ----------------

    private fun setupJson(a: Attempt): String {
        val setup = JSONObject()
        setup.put("model", "models/" + a.model)
        setup.put("responseModalities", JSONArray().put("AUDIO"))
        setup.put(
            "systemInstruction",
            JSONObject().put("parts", JSONArray().put(JSONObject().put("text", Prompt.TEXT)))
        )
        if (a.transcribe) {
            setup.put("inputAudioTranscription", JSONObject())
            setup.put("outputAudioTranscription", JSONObject())
        }
        if (a.tools) setup.put("tools", toolsJson())
        return JSONObject().put("setup", setup).toString()
    }

    private fun toolsJson(): JSONArray {
        val ctx = JSONObject()
        ctx.put("name", "get_market_context")
        ctx.put(
            "description",
            "Возвращает выбранный актив, текущую цену, изменение за 24 часа, последние цены, " +
                "баланс учебного счёта и открытую позицию."
        )
        val props = JSONObject()
        props.put("side", JSONObject().put("type", "STRING").put("description", "BUY (вверх) или SELL (вниз)"))
        props.put(
            "stop_loss_percent",
            JSONObject().put("type", "NUMBER").put("description", "Стоп-лосс в процентах от цены входа, например 1")
        )
        props.put(
            "take_profit_percent",
            JSONObject().put("type", "NUMBER").put("description", "Тейк-профит в процентах, например 2")
        )
        props.put("reason", JSONObject().put("type", "STRING").put("description", "Короткая причина сделки"))
        val params = JSONObject()
        params.put("type", "OBJECT")
        params.put("properties", props)
        params.put("required", JSONArray().put("side").put("stop_loss_percent"))
        val prop = JSONObject()
        prop.put("name", "propose_trade")
        prop.put(
            "description",
            "Показывает пользователю предложение учебной сделки. Сделку открывает только пользователь кнопкой."
        )
        prop.put("parameters", params)
        val decls = JSONArray()
        val simProps = JSONObject()
        simProps.put("minutes", JSONObject().put("type", "NUMBER").put("description", "Горизонт в минутах, например 15"))
        simProps.put("stop_loss_percent", JSONObject().put("type", "NUMBER").put("description", "Стоп-лосс в процентах, например 1"))
        simProps.put("take_profit_percent", JSONObject().put("type", "NUMBER").put("description", "Тейк-профит в процентах, например 2"))
        val simParams = JSONObject()
        simParams.put("type", "OBJECT")
        simParams.put("properties", simProps)
        val sim = JSONObject()
        sim.put("name", "run_simulation")
        sim.put(
            "description",
            "Запускает 10 000 симуляций пути цены выбранного актива и возвращает разброс и шанс задеть стоп или тейк. Это оценка волатильности, не прогноз."
        )
        sim.put("parameters", simParams)
        decls.put(ctx)
        decls.put(prop)
        decls.put(sim)
        return JSONArray().put(JSONObject().put("functionDeclarations", decls))
    }

    private fun runTool(name: String, args: JSONObject): JSONObject {
        val r = JSONObject()
        if (name == "get_market_context") {
            val sym = Market.selected
            r.put("symbol", sym)
            val pr = Market.price[sym]
            if (pr != null) r.put("price", pr) else r.put("price", "нет данных")
            val ch = Market.change[sym]
            if (ch != null) r.put("change_24h_percent", ch)
            val tail = JSONArray()
            for (v in Market.history(sym).takeLast(20)) tail.put(v)
            r.put("recent_prices", tail)
            r.put("balance_usdt", Paper.balance)
            val pos = Paper.pos
            r.put(
                "open_position",
                if (pos == null) "нет" else pos.side + " " + pos.symbol + " вход " + pos.entry
            )
            r.put("stats", Paper.statsText())
            if (Sentiment.allLong >= 0.0) r.put("long_share_all_traders_percent", Math.round(Sentiment.allLong * 100.0))
            if (Sentiment.topLong >= 0.0) r.put("long_share_top_traders_percent", Math.round(Sentiment.topLong * 100.0))
            if (Sentiment.bookBuy >= 0.0) r.put("orderbook_buyers_share_percent", Math.round(Sentiment.bookBuy * 100.0))
            if (!Sentiment.funding.isNaN()) r.put("funding_rate_percent", Sentiment.funding)
        } else if (name == "propose_trade") {
            val side = args.optString("side", "").uppercase(Locale.US)
            val buy = side.startsWith("B") || side == "UP" || side == "LONG"
            val sell = side.startsWith("S") || side == "DOWN" || side == "SHORT"
            if (!buy && !sell) {
                r.put("error", "side должен быть BUY или SELL")
            } else if (Paper.pos != null) {
                r.put("error", "уже есть открытая позиция")
            } else {
                var sl = args.optDouble("stop_loss_percent", 1.0)
                if (sl.isNaN() || sl <= 0.0) sl = 1.0
                sl = sl.coerceIn(0.2, 5.0)
                var tp = args.optDouble("take_profit_percent", sl * 2.0)
                if (tp.isNaN() || tp <= 0.0) tp = sl * 2.0
                tp = tp.coerceIn(0.2, 10.0)
                Paper.suggest(
                    Proposal(if (buy) "BUY" else "SELL", Market.selected, sl, tp, args.optString("reason", ""))
                )
                r.put(
                    "status",
                    "предложение показано пользователю и ждёт его подтверждения кнопкой в приложении; сделка ещё не открыта"
                )
            }
        } else if (name == "run_simulation") {
            var minutes = args.optInt("minutes", 15)
            if (minutes <= 0) minutes = 15
            var sl = args.optDouble("stop_loss_percent", 1.0)
            if (sl.isNaN() || sl <= 0.0) sl = 1.0
            sl = sl.coerceIn(0.2, 5.0)
            var tp = args.optDouble("take_profit_percent", sl * 2.0)
            if (tp.isNaN() || tp <= 0.0) tp = sl * 2.0
            tp = tp.coerceIn(0.2, 10.0)
            return Sim.toJson(Sim.compute(Market.selected, minutes, sl, tp, 0.1))
        } else {
            r.put("error", "неизвестная функция")
        }
        return r
    }

    private fun connect() {
        ready = false
        val a = attempts[attemptIdx]
        val gen = ++generation
        Bus.postStatus("Подключаюсь: " + a.model)
        val url = "wss://generativelanguage.googleapis.com/ws/" +
            "google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=" + apiKey
        val req = Request.Builder().url(url).build()
        ws = client.newWebSocket(req, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                if (gen != generation) return
                webSocket.send(setupJson(a))
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                if (gen == generation) handle(text)
            }

            override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                if (gen == generation) handle(bytes.utf8())
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                onDown(gen, "закрыто $code $reason")
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                onDown(gen, "ошибка ${response?.code ?: ""} ${t.message ?: ""}")
            }
        })
    }

    private fun onDown(gen: Int, why: String) {
        if (!active || gen != generation) return
        val wasReady = ready
        ready = false
        Bus.line("Связь прервалась: $why")
        if (!wasReady) {
            if (attemptIdx < attempts.size - 1) {
                attemptIdx++
                reconnectSoon()
            } else {
                Bus.postStatus("Не удалось подключиться")
                Bus.line("Проверь ключ и интернет.")
                stopSelf()
            }
        } else {
            fails++
            if (fails <= 5) {
                Bus.postStatus("Переподключаюсь...")
                reconnectSoon()
            } else {
                Bus.postStatus("Связь потеряна")
                stopSelf()
            }
        }
    }

    private fun reconnectSoon() {
        main.postDelayed({ if (active) connect() }, 1500)
    }

    private fun say(who: String, t: String) {
        if (t.isEmpty()) return
        if (speaker != who) {
            speaker = who
            Bus.append("\n\n$who: ")
        }
        Bus.append(t)
    }

    private fun handle(text: String) {
        val j = try {
            JSONObject(text)
        } catch (e: Exception) {
            return
        }
        if (j.has("setupComplete")) {
            ready = true
            fails = 0
            Bus.postStatus("Слушаю. Открой график и говори.")
            Bus.line("Готово (" + attempts[attemptIdx].model + ")")
            return
        }
        if (j.has("goAway")) {
            Bus.line("Сервер просит переподключиться.")
        }
        val tc = j.optJSONObject("toolCall")
        if (tc != null) {
            val calls = tc.optJSONArray("functionCalls")
            val responses = JSONArray()
            if (calls != null) {
                for (i in 0 until calls.length()) {
                    val c = calls.optJSONObject(i) ?: continue
                    val name = c.optString("name", "")
                    val id = c.optString("id", "")
                    val args = c.optJSONObject("args") ?: JSONObject()
                    val result = try {
                        runTool(name, args)
                    } catch (e: Exception) {
                        JSONObject().put("error", e.message ?: "ошибка")
                    }
                    val item = JSONObject()
                    item.put("name", name)
                    item.put("id", id)
                    item.put("response", JSONObject().put("result", result))
                    responses.put(item)
                }
            }
            ws?.send(JSONObject().put("toolResponse", JSONObject().put("functionResponses", responses)).toString())
            return
        }
        val sc = j.optJSONObject("serverContent") ?: return
        if (sc.optBoolean("interrupted")) flushPlayback()

        val parts = sc.optJSONObject("modelTurn")?.optJSONArray("parts")
        if (parts != null) {
            for (i in 0 until parts.length()) {
                val inline = parts.optJSONObject(i)?.optJSONObject("inlineData") ?: continue
                val d = inline.optString("data", "")
                if (d.isNotEmpty()) playQueue.offer(Base64.decode(d, Base64.DEFAULT))
            }
        }
        sc.optJSONObject("inputTranscription")?.let { say("Ты", it.optString("text", "")) }
        sc.optJSONObject("outputTranscription")?.let { say("ИИ", it.optString("text", "")) }
    }

    // ---------------- Остановка ----------------

    override fun onDestroy() {
        active = false
        Bus.running = false
        ready = false
        generation++
        try { ws?.close(1000, "bye") } catch (e: Exception) { }
        try { rec?.stop() } catch (e: Exception) { }
        try { rec?.release() } catch (e: Exception) { }
        try { track?.stop() } catch (e: Exception) { }
        try { track?.release() } catch (e: Exception) { }
        try { vDisplay?.release() } catch (e: Exception) { }
        try { reader?.close() } catch (e: Exception) { }
        try { projection?.stop() } catch (e: Exception) { }
        try { imgThread?.quitSafely() } catch (e: Exception) { }
        Bus.postStatus("Остановлено")
        super.onDestroy()
    }
}
