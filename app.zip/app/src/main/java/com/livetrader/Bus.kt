package com.livetrader

import android.os.Handler
import android.os.Looper

/** Простой обмен между сервисом, рынком и экраном (всё в одном процессе). */
object Bus {
    private val main = Handler(Looper.getMainLooper())
    private val buf = StringBuilder()

    @Volatile var status: String = "Live выключен. Нажми Старт."
    @Volatile var onChange: (() -> Unit)? = null
    @Volatile var running: Boolean = false     // идёт ли сессия Live
    @Volatile var uiVisible: Boolean = false   // открыт ли экран приложения

    val text: String
        get() = synchronized(buf) { buf.toString() }

    fun setStatus(s: String) {
        status = s
        notifyChange()
    }

    /** Добавить кусок текста без перевода строки (для потока расшифровки). */
    fun append(s: String) {
        synchronized(buf) {
            buf.append(s)
            if (buf.length > 8000) buf.delete(0, buf.length - 6000)
        }
        notifyChange()
    }

    fun line(s: String) = append("\n" + s)

    fun ping() = notifyChange()

    private fun notifyChange() {
        val cb = onChange ?: return
        main.post { cb() }
    }
}
