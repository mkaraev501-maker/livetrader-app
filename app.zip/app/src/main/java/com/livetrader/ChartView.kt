package com.livetrader

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.view.View

/** Простой линейный график последних цен. */
class ChartView(ctx: Context) : View(ctx) {
    var data: List<Double> = emptyList()

    private val line = Paint(Paint.ANTI_ALIAS_FLAG)
    private val grid = Paint()

    init {
        line.strokeWidth = 3f
        line.style = Paint.Style.STROKE
        grid.color = 0x33FFFFFF
        grid.strokeWidth = 1f
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w = width.toFloat()
        val h = height.toFloat()
        c.drawLine(0f, h / 2f, w, h / 2f, grid)
        val d = data
        val n = d.size
        if (n < 2) return
        var mn = d[0]
        var mx = d[0]
        for (v in d) {
            if (v < mn) mn = v
            if (v > mx) mx = v
        }
        val rng = if (mx - mn < 1e-12) 1.0 else mx - mn
        line.color = if (d[n - 1] >= d[0]) 0xFF2ECC71.toInt() else 0xFFE74C3C.toInt()
        val path = Path()
        for (i in 0 until n) {
            val x = w * i / (n - 1).toFloat()
            val y = (h - 6f) - ((d[i] - mn) / rng * (h - 12f)).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        c.drawPath(path, line)
    }
}
