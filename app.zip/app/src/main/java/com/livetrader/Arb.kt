package com.livetrader

import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale

/**
 * Сканер треугольного арбитража на живых ценах Binance (лучшие bid/ask).
 * Только считает и показывает. Никаких ордеров не отправляет.
 * Цепочки: USDT > M > X > USDT и обратная USDT > X > M > USDT, где M = BTC, ETH или BNB.
 */
object Arb {
    private class Quote(val bid: Double, val bidQty: Double, val ask: Double, val askQty: Double)
    private class Tri(val x: String, val mid: String)
    private class Row(val path: String, val gross: Double, val net: Double, val cap: Double)

    @Volatile var enabled: Boolean = false
    @Volatile var feePct: Double = 0.1
    @Volatile private var lastError: String = ""
    @Volatile private var rows: List<Row> = emptyList()
    @Volatile private var scans: Int = 0
    @Volatile private var positive: Int = 0
    @Volatile private var bestNet: Double = -100.0
    @Volatile private var bestPath: String = ""

    private val mids = listOf("BTC", "ETH", "BNB")
    private val assets = listOf(
        "SOL", "XRP", "ADA", "DOGE", "LTC", "LINK", "DOT", "AVAX", "TRX", "ATOM",
        "UNI", "ETC", "BCH", "NEAR", "FIL", "APT", "ARB", "OP", "SUI", "INJ",
        "SEI", "TON", "PEPE", "SHIB"
    )

    private var triangles: List<Tri> = emptyList()
    private var watch: List<String> = emptyList()
    private var lastDiscovery = 0L
    private var thread: Thread? = null
    private val bases = listOf("https://data-api.binance.vision", "https://api.binance.com")

    @Synchronized
    fun start() {
        if (thread?.isAlive == true) return
        val t = Thread { loop() }
        t.isDaemon = true
        thread = t
        t.start()
    }

    fun toggle() {
        enabled = !enabled
        Bus.ping()
    }

    fun resetStats() {
        scans = 0
        positive = 0
        bestNet = -100.0
        bestPath = ""
        rows = emptyList()
        Bus.ping()
    }

    private fun loop() {
        while (true) {
            if (enabled && Bus.uiVisible) {
                try {
                    scanOnce()
                } catch (e: Exception) {
                    lastError = e.message ?: e.toString()
                }
                Bus.ping()
            }
            try {
                Thread.sleep(3000)
            } catch (e: InterruptedException) {
                return
            }
        }
    }

    private fun httpGet(path: String): String {
        var err: Exception? = null
        for (b in bases) {
            var conn: HttpURLConnection? = null
            try {
                conn = URL(b + path).openConnection() as HttpURLConnection
                conn.connectTimeout = 8000
                conn.readTimeout = 15000
                return conn.inputStream.bufferedReader().use { it.readText() }
            } catch (e: Exception) {
                err = e
            } finally {
                conn?.disconnect()
            }
        }
        throw err ?: RuntimeException("нет связи")
    }

    private fun parse(body: String): Map<String, Quote> {
        val out = HashMap<String, Quote>()
        val arr = JSONArray(body)
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val bid = o.optString("bidPrice", "0").toDoubleOrNull() ?: 0.0
            val bq = o.optString("bidQty", "0").toDoubleOrNull() ?: 0.0
            val ask = o.optString("askPrice", "0").toDoubleOrNull() ?: 0.0
            val aq = o.optString("askQty", "0").toDoubleOrNull() ?: 0.0
            if (bid > 0.0 && ask > 0.0) out[o.getString("symbol")] = Quote(bid, bq, ask, aq)
        }
        return out
    }

    /** Раз в 10 минут скачиваем все пары и находим, какие цепочки вообще существуют. */
    private fun discover(): Map<String, Quote> {
        val all = parse(httpGet("/api/v3/ticker/bookTicker"))
        val tris = ArrayList<Tri>()
        val need = LinkedHashSet<String>()
        for (x in assets) {
            for (m in mids) {
                if (x == m) continue
                val mu = m + "USDT"
                val xm = x + m
                val xu = x + "USDT"
                if (all.containsKey(mu) && all.containsKey(xm) && all.containsKey(xu)) {
                    tris.add(Tri(x, m))
                    need.add(mu)
                    need.add(xm)
                    need.add(xu)
                }
            }
        }
        triangles = tris
        watch = need.toList()
        lastDiscovery = System.currentTimeMillis()
        return all
    }

    private fun scanOnce() {
        val now = System.currentTimeMillis()
        val q: Map<String, Quote> =
            if (triangles.isEmpty() || now - lastDiscovery > 600000L) {
                discover()
            } else {
                val json = JSONArray()
                for (s in watch) json.put(s)
                parse(httpGet("/api/v3/ticker/bookTicker?symbols=" + URLEncoder.encode(json.toString(), "UTF-8")))
            }

        val f = feePct / 100.0
        val k = (1.0 - f) * (1.0 - f) * (1.0 - f)
        val res = ArrayList<Row>()
        for (t in triangles) {
            val mu = q[t.mid + "USDT"]
            val xm = q[t.x + t.mid]
            val xu = q[t.x + "USDT"]
            if (mu == null || xm == null || xu == null) continue

            // USDT > M > X > USDT: покупаем M, на M покупаем X, X продаём за USDT
            val grossA = (1.0 / mu.ask) * (1.0 / xm.ask) * xu.bid
            val capA = minOf(mu.askQty * mu.ask, xm.askQty * xu.bid, xu.bidQty * xu.bid)
            res.add(Row("USDT>" + t.mid + ">" + t.x + ">USDT", (grossA - 1.0) * 100.0, (grossA * k - 1.0) * 100.0, capA))

            // USDT > X > M > USDT: покупаем X, X продаём за M, M продаём за USDT
            val grossB = (1.0 / xu.ask) * xm.bid * mu.bid
            val capB = minOf(xu.askQty * xu.ask, xm.bidQty * xu.ask, mu.bidQty * mu.bid)
            res.add(Row("USDT>" + t.x + ">" + t.mid + ">USDT", (grossB - 1.0) * 100.0, (grossB * k - 1.0) * 100.0, capB))
        }
        res.sortByDescending { it.net }
        scans++
        val top = res.firstOrNull()
        if (top != null) {
            if (top.net > 0.0) positive++
            if (top.net > bestNet) {
                bestNet = top.net
                bestPath = top.path
            }
        }
        rows = res.take(8)
        lastError = ""
    }

    private fun pct(v: Double): String = String.format(Locale.US, "%+.3f", v) + "%"

    fun report(): String {
        if (!enabled) return "Сканер выключен."
        val r = rows
        if (r.isEmpty()) {
            return if (lastError.isEmpty()) "Ищу цепочки..." else "Нет данных: " + lastError.take(80)
        }
        val sb = StringBuilder()
        sb.append("Комиссия ").append(feePct).append("% за обмен, в цепочке 3 обмена.\n")
        for (row in r) {
            sb.append("\n").append(row.path.replace(">", " > ")).append("\n")
            sb.append("  до комиссии ").append(pct(row.gross))
            sb.append(", после ").append(pct(row.net))
            sb.append(", объём до ~").append(row.cap.toInt()).append(" USDT\n")
        }
        sb.append("\nПроверок: ").append(scans)
        sb.append(". Лучшая цепочка была в плюсе после комиссии: ").append(positive).append(" раз.")
        if (bestPath.isNotEmpty()) {
            sb.append("\nЛучший результат за всё время: ").append(pct(bestNet)).append(" (")
            sb.append(bestPath.replace(">", " > ")).append(")")
        }
        sb.append("\nЦены лучшие в стакане на момент запроса. Пока ты бы выполнил три обмена, они уже изменились, поэтому на деле результат хуже.")
        return sb.toString()
    }
}
