package com.livetrader

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity() {
    private val symbols = listOf(
        "BTCUSDT", "ETHUSDT", "BNBUSDT", "SOLUSDT", "XRPUSDT",
        "DOGEUSDT", "ADAUSDT", "LTCUSDT", "EURUSDT"
    )

    private lateinit var keyInput: EditText
    private lateinit var statusView: TextView
    private lateinit var logView: TextView
    private lateinit var priceView: TextView
    private lateinit var chart: ChartView
    private lateinit var accountView: TextView
    private lateinit var posView: TextView
    private lateinit var sizeInput: EditText
    private lateinit var slInput: EditText
    private lateinit var tpInput: EditText
    private lateinit var proposalBox: LinearLayout
    private lateinit var proposalText: TextView
    private lateinit var arbBtn: Button
    private lateinit var arbFee: EditText
    private lateinit var arbView: TextView
    private lateinit var barAll: BarView
    private lateinit var barTop: BarView
    private lateinit var barBook: BarView
    private lateinit var sentView: TextView
    private lateinit var simMinutes: EditText
    private lateinit var simView: TextView

    private var dp = 1f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Paper.init(this)
        Market.start()
        Arb.start()
        Sentiment.start()
        dp = resources.displayMetrics.density
        val pad = (16 * dp).toInt()

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(pad, pad * 2, pad, pad)

        root.addView(label("Live Трейдер", 24f))
        root.addView(label("Учебный счёт на виртуальные деньги. Реальных сделок здесь нет.", 13f))

        // ---------- Live ----------
        root.addView(space())
        root.addView(label("Голосовой помощник (Gemini Live)", 17f))
        keyInput = EditText(this)
        keyInput.hint = "Ключ Gemini API"
        keyInput.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        keyInput.setSingleLine()
        keyInput.setText(getSharedPreferences("cfg", MODE_PRIVATE).getString("key", ""))
        root.addView(keyInput)

        val liveRow = row()
        liveRow.addView(button("Старт") { onStartClicked() }, weight())
        liveRow.addView(button("Стоп") { stopService(Intent(this, LiveService::class.java)) }, weight())
        root.addView(liveRow)

        statusView = label("", 15f)
        root.addView(statusView)

        // ---------- Актив и цена ----------
        root.addView(space())
        root.addView(label("Актив и цена", 17f))
        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, symbols)
        val saved = getSharedPreferences("cfg", MODE_PRIVATE).getString("symbol", symbols[0]) ?: symbols[0]
        val idx = symbols.indexOf(saved).let { if (it < 0) 0 else it }
        Market.selected = symbols[idx]
        spinner.setSelection(idx)
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                Market.selected = symbols[position]
                getSharedPreferences("cfg", MODE_PRIVATE).edit().putString("symbol", symbols[position]).apply()
                refresh()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        root.addView(spinner)

        priceView = label("", 20f)
        root.addView(priceView)

        chart = ChartView(this)
        root.addView(chart, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (150 * dp).toInt()))

        // ---------- Кто покупает, кто продаёт ----------
        root.addView(space())
        root.addView(label("Кто покупает, кто продаёт", 17f))
        root.addView(label("Все трейдеры на фьючерсах (по числу аккаунтов)", 12f))
        barAll = BarView(this)
        root.addView(barAll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (30 * dp).toInt()))
        root.addView(label("Крупные трейдеры (по размеру позиций)", 12f))
        barTop = BarView(this)
        root.addView(barTop, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (30 * dp).toInt()))
        root.addView(label("Стакан: объём покупателей и продавцов у цены", 12f))
        barBook = BarView(this)
        barBook.leftLabel = "Покупают"
        barBook.rightLabel = "Продают"
        root.addView(barBook, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (30 * dp).toInt()))
        sentView = label("", 13f)
        root.addView(sentView)

        // ---------- Торговля ----------
        root.addView(space())
        root.addView(label("Учебная торговля", 17f))
        accountView = label("", 14f)
        root.addView(accountView)
        posView = label("", 14f)
        root.addView(posView)

        val inputs = row()
        sizeInput = numberInput("Размер USDT", "100")
        slInput = numberInput("Стоп %", "1")
        tpInput = numberInput("Тейк %", "2")
        inputs.addView(sizeInput, weight())
        inputs.addView(slInput, weight())
        inputs.addView(tpInput, weight())
        root.addView(inputs)

        val tradeRow = row()
        tradeRow.addView(button("Вверх") { trade("BUY") }, weight())
        tradeRow.addView(button("Вниз") { trade("SELL") }, weight())
        tradeRow.addView(button("Закрыть") { closeNow() }, weight())
        root.addView(tradeRow)

        proposalBox = LinearLayout(this)
        proposalBox.orientation = LinearLayout.VERTICAL
        proposalText = label("", 14f)
        proposalBox.addView(proposalText)
        val prow = row()
        prow.addView(button("Подтвердить") { confirmProposal() }, weight())
        prow.addView(button("Отклонить") { Paper.clearProposal() }, weight())
        proposalBox.addView(prow)
        proposalBox.visibility = View.GONE
        root.addView(proposalBox)

        // ---------- Симуляция ----------
        root.addView(space())
        root.addView(label("Симуляция 10 000 путей", 17f))
        root.addView(label("Оценка разброса цены и шанса задеть стоп или тейк. Это не прогноз. Стоп и тейк берутся из полей выше.", 13f))
        val simRow = row()
        simMinutes = numberInput("Минут вперёд", "15")
        simRow.addView(simMinutes, weight())
        simRow.addView(button("Запустить симуляцию") { runSim() }, weight())
        root.addView(simRow)
        simView = label("", 13f)
        root.addView(simView)

        // ---------- Треугольный арбитраж ----------
        root.addView(space())
        root.addView(label("Сканер треугольного арбитража", 17f))
        root.addView(label("Только считает на живых ценах Binance. Сделок не делает.", 13f))
        val arbRow = row()
        arbFee = numberInput("Комиссия %", "0.1")
        arbBtn = button("Сканер: ВЫКЛ") {
            Arb.feePct = num(arbFee, 0.1).coerceIn(0.0, 1.0)
            Arb.toggle()
        }
        arbRow.addView(arbFee, weight())
        arbRow.addView(arbBtn, weight())
        root.addView(arbRow)
        arbView = label("", 13f)
        root.addView(arbView)
        root.addView(button("Сбросить статистику сканера") { Arb.resetStats() })

        // ---------- Журнал ----------
        root.addView(space())
        root.addView(label("Журнал", 17f))
        logView = label("", 14f)
        root.addView(logView)
        root.addView(button("Сбросить счёт") {
            AlertDialog.Builder(this)
                .setMessage("Сбросить виртуальный счёт до 10000 USDT и очистить сделки?")
                .setPositiveButton("Да") { _, _ -> Paper.reset() }
                .setNegativeButton("Нет", null)
                .show()
        })

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }

    // ---------- помощники для интерфейса ----------

    private fun label(t: String, size: Float): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = size
        v.setPadding(0, (4 * dp).toInt(), 0, (4 * dp).toInt())
        return v
    }

    private fun space(): View {
        val v = View(this)
        v.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (14 * dp).toInt())
        return v
    }

    private fun row(): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        return r
    }

    private fun weight(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)

    private fun button(t: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = t
        b.setOnClickListener { onClick() }
        return b
    }

    private fun numberInput(hint: String, def: String): EditText {
        val e = EditText(this)
        e.hint = hint
        e.setText(def)
        e.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        e.setSingleLine()
        e.textSize = 14f
        return e
    }

    private fun num(e: EditText, def: Double): Double =
        e.text.toString().replace(',', '.').toDoubleOrNull() ?: def

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    // ---------- жизненный цикл ----------

    override fun onResume() {
        super.onResume()
        Bus.uiVisible = true
        Bus.onChange = { refresh() }
        refresh()
    }

    override fun onPause() {
        Bus.uiVisible = false
        Bus.onChange = null
        super.onPause()
    }

    private fun refresh() {
        statusView.text = Bus.status
        logView.text = Bus.text.takeLast(1500)

        val sym = Market.selected
        val p = Market.price[sym]
        val ch = Market.change[sym]
        if (p == null) {
            priceView.text = if (Market.lastError.isEmpty()) "$sym: загрузка цены..."
            else "$sym: нет цены. " + Market.lastError.take(80)
        } else {
            priceView.text = sym + "  " + fmtPrice(p) + (if (ch != null) "  (" + fmtSigned(ch) + "% за 24ч)" else "")
        }
        chart.data = Market.history(sym)
        chart.invalidate()

        accountView.text = "Баланс: " + fmtPrice(Paper.balance) + " USDT\n" + Paper.statsText()

        val pos = Paper.pos
        if (pos == null) {
            posView.text = "Позиция: нет"
        } else {
            val cur = Market.price[pos.symbol]
            val pnl = if (cur != null) Paper.unrealized(pos, cur) else 0.0
            posView.text = "Позиция: " + (if (pos.side == "BUY") "ВВЕРХ " else "ВНИЗ ") + pos.symbol +
                "\nвход " + fmtPrice(pos.entry) + ", размер " + fmtPrice(pos.size) + " USDT" +
                "\nстоп " + fmtPrice(pos.slPrice) + (if (pos.tpPrice > 0.0) ", тейк " + fmtPrice(pos.tpPrice) else "") +
                "\nсейчас: " + fmtSigned(pnl) + " USDT"
        }

        val pr = Paper.proposal
        if (pr == null) {
            proposalBox.visibility = View.GONE
        } else {
            proposalText.text = "Помощник предлагает: " + (if (pr.side == "BUY") "ВВЕРХ " else "ВНИЗ ") + pr.symbol +
                ", стоп " + pr.slPct + "%, тейк " + pr.tpPct + "%\n" + pr.reason
            proposalBox.visibility = View.VISIBLE
        }

        arbBtn.text = if (Arb.enabled) "Сканер: ВКЛ" else "Сканер: ВЫКЛ"
        arbView.text = Arb.report()

        barAll.frac = Sentiment.allLong
        barAll.invalidate()
        barTop.frac = Sentiment.topLong
        barTop.invalidate()
        barBook.frac = Sentiment.bookBuy
        barBook.invalidate()
        val base = Market.selected.removeSuffix("USDT")
        val sbs = StringBuilder()
        if (!Sentiment.funding.isNaN()) {
            sbs.append("Ставка финансирования: ").append(String.format(Locale.US, "%+.4f", Sentiment.funding))
            sbs.append("% (плюс: лонги платят шортам)\n")
        }
        if (!Sentiment.openInterest.isNaN()) {
            sbs.append("Открытый интерес: ").append(String.format(Locale.US, "%,.0f", Sentiment.openInterest))
            sbs.append(" ").append(base).append("\n")
        }
        if (Sentiment.futuresNote.isNotEmpty()) sbs.append(Sentiment.futuresNote.take(90)).append("\n")
        if (Sentiment.bookNote.isNotEmpty()) sbs.append(Sentiment.bookNote.take(90)).append("\n")
        sbs.append("Это контекст, не сигнал: когда почти все в одну сторону, цена иногда идёт против толпы.")
        sentView.text = sbs.toString()
        simView.text = Sim.text
    }

    private fun runSim() {
        if (Sim.busy) {
            toast("Уже считаю")
            return
        }
        Sim.runAsync(Market.selected, num(simMinutes, 15.0).toInt(), num(slInput, 1.0), num(tpInput, 2.0))
    }

    // ---------- торговля ----------

    private fun trade(side: String) {
        val sym = Market.selected
        val price = Market.price[sym]
        if (price == null) {
            toast("Цена ещё не загрузилась")
            return
        }
        val err = Paper.open(side, sym, price, num(sizeInput, 100.0), num(slInput, 1.0), num(tpInput, 2.0))
        if (err != null) toast(err)
    }

    private fun closeNow() {
        val pos = Paper.pos
        if (pos == null) {
            toast("Нет открытой позиции")
            return
        }
        val price = Market.price[pos.symbol]
        if (price == null) {
            toast("Нет цены")
            return
        }
        Paper.close(price, "вручную")
    }

    private fun confirmProposal() {
        val pr = Paper.proposal ?: return
        val price = Market.price[pr.symbol]
        if (price == null) {
            toast("Цена ещё не загрузилась")
            return
        }
        val err = Paper.open(pr.side, pr.symbol, price, num(sizeInput, 100.0), pr.slPct, pr.tpPct)
        if (err != null) toast(err)
    }

    // ---------- Live ----------

    private fun onStartClicked() {
        val key = keyInput.text.toString().trim()
        if (key.isEmpty()) {
            toast("Вставь ключ Gemini API")
            return
        }
        getSharedPreferences("cfg", MODE_PRIVATE).edit().putString("key", key).apply()
        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        requestPermissions(perms.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != 1) return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Без микрофона не работает", Toast.LENGTH_LONG).show()
            return
        }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), 2)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 2) return
        if (resultCode != RESULT_OK || data == null) {
            Toast.makeText(this, "Нужно разрешить запись экрана", Toast.LENGTH_LONG).show()
            return
        }
        val key = keyInput.text.toString().trim()
        val i = Intent(this, LiveService::class.java)
        i.putExtra("code", resultCode)
        i.putExtra("data", data)
        i.putExtra("key", key)
        startForegroundService(i)
        Bus.setStatus("Запускаю...")
    }
}
