package com.livetrader

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap

/** Живые цены с публичного API Binance (без ключей). Опрос раз в 2 секунды. */
object Market {
    @Volatile var selected: String = "BTCUSDT"
    @Volatile var lastError: String = ""
    val price = ConcurrentHashMap<String, Double>()
    val change = ConcurrentHashMap<String, Double>()

    private val hist = HashMap<String, ArrayList<Double>>()
    private var thread: Thread? = null
    private val bases = listOf("https://data-api.binance.vision", "https://api.binance.com")

    fun history(sym: String): List<Double> = synchronized(hist) {
        val l = hist[sym]
        if (l == null) emptyList<Double>() else ArrayList<Double>(l)
    }

    @Synchronized
    fun start() {
        if (thread?.isAlive == true) return
        val t = Thread { loop() }
        t.isDaemon = true
        thread = t
        t.start()
    }

    private fun loop() {
        while (true) {
            if (Bus.uiVisible || Bus.running) {
                val syms = HashSet<String>()
                syms.add(selected)
                val p = Paper.pos
                if (p != null) syms.add(p.symbol)
                for (s in syms) fetch(s)
                Bus.ping()
            }
            try {
                Thread.sleep(2000)
            } catch (e: InterruptedException) {
                return
            }
        }
    }

    private fun fetch(sym: String) {
        for (b in bases) {
            var conn: HttpURLConnection? = null
            try {
                conn = URL("$b/api/v3/ticker/24hr?symbol=$sym").openConnection() as HttpURLConnection
                conn.connectTimeout = 5000
                conn.readTimeout = 5000
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                val j = JSONObject(body)
                val p = j.getString("lastPrice").toDouble()
                val c = j.getString("priceChangePercent").toDouble()
                price[sym] = p
                change[sym] = c
                synchronized(hist) {
                    val l = hist.getOrPut(sym) { ArrayList<Double>() }
                    l.add(p)
                    if (l.size > 150) l.removeAt(0)
                }
                lastError = ""
                Paper.onPrice(sym, p)
                return
            } catch (e: Exception) {
                lastError = e.message ?: e.toString()
            } finally {
                conn?.disconnect()
            }
        }
    }
}
