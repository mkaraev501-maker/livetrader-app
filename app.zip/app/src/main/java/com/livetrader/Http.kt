package com.livetrader

import java.net.HttpURLConnection
import java.net.URL

/** Маленький помощник для запросов без лишних библиотек. */
object Http {
    fun get(url: String, timeoutMs: Int = 8000): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = timeoutMs
            conn.readTimeout = timeoutMs + 7000
            val code = conn.responseCode
            if (code !in 200..299) throw RuntimeException("HTTP $code")
            return conn.inputStream.bufferedReader().use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }

    /** Пробует несколько адресов по очереди. */
    fun getAny(bases: List<String>, path: String): String {
        var err: Exception? = null
        for (b in bases) {
            try {
                return get(b + path)
            } catch (e: Exception) {
                err = e
            }
        }
        throw err ?: RuntimeException("нет связи")
    }
}
