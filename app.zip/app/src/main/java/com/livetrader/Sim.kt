package com.livetrader

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.Random
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.sqrt

/**
 * Симуляция Монте-Карло: 10 000 возможных путей цены.
 * Берём реальные минутные изменения цены за последние ~8 часов, убираем средний наклон
 * (чтобы не придумывать тренд) и случайно перемешиваем. Это оценка разброса, а не прогноз.
 */
object Sim {
    const val PATHS = 10000

    class Out(
        val symbol: String, val minutes: Int, val volPerMinPct: Double,
        val pUp: Double, val p5: Double, val median: Double, val p95: Double,
        val slPct: Double, val tpPct: Double,
        val longTp: Double, val longSl: Double, val longEv: Double,
        val shortTp: Double, val shortSl: Double, val shortEv: Double
    )

    @Volatile var text: String = "Нажми «Запустить симуляцию»."
    @Volatile var busy: Boolean = false

    fun runAsync(symbol: String, minutes: Int, slPct: Double, tpPct: Double) {
        if (busy) return
        busy = true
        text = "Считаю 10 000 путей..."
        Bus.ping()
        val t = Thread {
            try {
                text = format(compute(symbol, minutes, slPct, tpPct, 0.1))
            } catch (e: Exception) {
                text = "Не получилось: " + (e.message ?: e.toString())
            } finally {
                busy = false
                Bus.ping()
            }
        }
        t.isDaemon = true
        t.start()
    }

    fun compute(symbol: String, minutesIn: Int, slPct: Double, tpPct: Double, feePct: Double): Out {
        val raw = Http.getAny(
            listOf("https://data-api.binance.vision", "https://api.binance.com"),
            "/api/v3/klines?symbol=$symbol&interval=1m&limit=500"
        )
        val arr = JSONArray(raw)
        val m = arr.length()
        if (m < 60) throw RuntimeException("мало истории цен")
        val closes = DoubleArray(m)
        for (i in 0 until m) closes[i] = arr.getJSONArray(i).getString(4).toDouble()
        val rets = DoubleArray(m - 1)
        for (i in 0 until m - 1) rets[i] = ln(closes[i + 1] / closes[i])
        var mean = 0.0
        for (r in rets) mean += r
        mean /= rets.size
        var ss = 0.0
        for (i in rets.indices) {
            rets[i] -= mean
            ss += rets[i] * rets[i]
        }
        val vol = sqrt(ss / rets.size)

        val steps = minutesIn.coerceIn(1, 240)
        val sl = slPct / 100.0
        val tpOn = tpPct > 0.0
        val tp = tpPct / 100.0
        val rnd = Random()
        val finals = DoubleArray(PATHS)
        var up = 0
        var lTp = 0
        var lSl = 0
        var sTp = 0
        var sSl = 0
        var evL = 0.0
        var evS = 0.0

        for (p in 0 until PATHS) {
            var logP = 0.0
            var lState = 0   // 0 пока ничего, 1 тейк, 2 стоп
            var sState = 0
            for (s in 0 until steps) {
                logP += rets[rnd.nextInt(rets.size)]
                val price = exp(logP)
                if (lState == 0) {
                    if (price <= 1.0 - sl) lState = 2
                    else if (tpOn && price >= 1.0 + tp) lState = 1
                }
                if (sState == 0) {
                    if (price >= 1.0 + sl) sState = 2
                    else if (tpOn && price <= 1.0 - tp) sState = 1
                }
            }
            val fin = (exp(logP) - 1.0) * 100.0
            finals[p] = fin
            if (fin > 0.0) up++
            when (lState) {
                1 -> { lTp++; evL += tpPct }
                2 -> { lSl++; evL -= slPct }
                else -> evL += fin
            }
            when (sState) {
                1 -> { sTp++; evS += tpPct }
                2 -> { sSl++; evS -= slPct }
                else -> evS -= fin
            }
        }
        finals.sort()
        val n = PATHS.toDouble()
        val roundTripFee = feePct * 2.0
        return Out(
            symbol, steps, vol * 100.0,
            up / n,
            finals[(PATHS * 0.05).toInt()], finals[PATHS / 2], finals[(PATHS * 0.95).toInt()],
            slPct, tpPct,
            lTp / n, lSl / n, evL / n - roundTripFee,
            sTp / n, sSl / n, evS / n - roundTripFee
        )
    }

    private fun pc(x: Double): String = String.format(Locale.US, "%.1f", x * 100.0) + "%"
    private fun sg(x: Double): String = String.format(Locale.US, "%+.2f", x) + "%"

    fun format(o: Out): String {
        val sb = StringBuilder()
        sb.append("10 000 путей, ").append(o.symbol).append(", на ").append(o.minutes).append(" мин вперёд\n")
        sb.append("Обычный шаг цены за минуту: около ±").append(String.format(Locale.US, "%.3f", o.volPerMinPct)).append("%\n\n")
        sb.append("К концу выше текущей цены: ").append(pc(o.pUp)).append(", ниже: ").append(pc(1.0 - o.pUp)).append("\n")
        sb.append("Разброс конца пути: 5% худших ").append(sg(o.p5)).append(", середина ").append(sg(o.median))
        sb.append(", 5% лучших ").append(sg(o.p95)).append("\n\n")
        val none = 1.0 - o.longTp - o.longSl
        sb.append("Позиция ВВЕРХ (стоп ").append(o.slPct).append("%, тейк ").append(o.tpPct).append("%):\n")
        sb.append("  тейк первым ").append(pc(o.longTp)).append(", стоп первым ").append(pc(o.longSl))
        sb.append(", ни то ни другое ").append(pc(none)).append("\n")
        sb.append("  в среднем за сделку после комиссии: ").append(sg(o.longEv)).append("\n")
        val noneS = 1.0 - o.shortTp - o.shortSl
        sb.append("Позиция ВНИЗ:\n")
        sb.append("  тейк первым ").append(pc(o.shortTp)).append(", стоп первым ").append(pc(o.shortSl))
        sb.append(", ни то ни другое ").append(pc(noneS)).append("\n")
        sb.append("  в среднем за сделку после комиссии: ").append(sg(o.shortEv)).append("\n\n")
        sb.append("Это оценка разброса по недавней истории, а не прогноз. Тренд в расчёт не заложен, поэтому вверх и вниз почти поровну. Проверка идёт по закрытиям минут, резкие проколы внутри минуты не видны.")
        return sb.toString()
    }

    private fun r1(x: Double): Double = Math.round(x * 10.0) / 10.0

    fun toJson(o: Out): JSONObject {
        val j = JSONObject()
        j.put("symbol", o.symbol)
        j.put("minutes", o.minutes)
        j.put("paths", PATHS)
        j.put("volatility_per_minute_percent", Math.round(o.volPerMinPct * 1000.0) / 1000.0)
        j.put("prob_end_above_current_percent", r1(o.pUp * 100.0))
        j.put("end_move_5th_percentile_percent", Math.round(o.p5 * 100.0) / 100.0)
        j.put("end_move_median_percent", Math.round(o.median * 100.0) / 100.0)
        j.put("end_move_95th_percentile_percent", Math.round(o.p95 * 100.0) / 100.0)
        j.put("stop_loss_percent", o.slPct)
        j.put("take_profit_percent", o.tpPct)
        j.put("long_take_profit_first_percent", r1(o.longTp * 100.0))
        j.put("long_stop_first_percent", r1(o.longSl * 100.0))
        j.put("long_avg_result_after_fees_percent", Math.round(o.longEv * 100.0) / 100.0)
        j.put("short_take_profit_first_percent", r1(o.shortTp * 100.0))
        j.put("short_stop_first_percent", r1(o.shortSl * 100.0))
        j.put("short_avg_result_after_fees_percent", Math.round(o.shortEv * 100.0) / 100.0)
        j.put("note", "оценка разброса без тренда, не прогноз")
        return j
    }
}
