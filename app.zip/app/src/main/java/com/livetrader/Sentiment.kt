package com.livetrader

import org.json.JSONArray
import org.json.JSONObject

/**
 * Кто покупает и кто продаёт.
 * Фьючерсы Binance: доля лонгов у всех и у крупных трейдеров, ставка финансирования, открытый интерес.
 * Спот: баланс покупателей и продавцов в стакане около цены.
 */
object Sentiment {
    @Volatile var allLong: Double = -1.0      // доля лонгов 0..1, меньше 0 = нет данных
    @Volatile var topLong: Double = -1.0
    @Volatile var bookBuy: Double = -1.0      // доля покупателей в стакане 0..1
    @Volatile var funding: Double = Double.NaN      // в процентах
    @Volatile var openInterest: Double = Double.NaN // в монетах
    @Volatile var futuresNote: String = ""
    @Volatile var bookNote: String = ""

    private var thread: Thread? = null
    private var lastSym = ""
    private var tick = 0
    private val spot = listOf("https://data-api.binance.vision", "https://api.binance.com")
    private const val FUT = "https://fapi.binance.com"

    @Synchronized
    fun start() {
        if (thread?.isAlive == true) return
        val t = Thread { loop() }
        t.isDaemon = true
        thread = t
        t.start()
    }

    private fun loop() {
        while (true) {
            if (Bus.uiVisible || Bus.running) {
                val sym = Market.selected
                if (sym != lastSym) {
                    lastSym = sym
                    allLong = -1.0
                    topLong = -1.0
                    bookBuy = -1.0
                    funding = Double.NaN
                    openInterest = Double.NaN
                    futuresNote = ""
                    bookNote = ""
                    tick = 0
                }
                if (tick % 10 == 0) refreshBook(sym)
                if (tick % 60 == 0) refreshFutures(sym)
                tick++
                Bus.ping()
            }
            try {
                Thread.sleep(1000)
            } catch (e: InterruptedException) {
                return
            }
        }
    }

    private fun refreshBook(sym: String) {
        try {
            val o = JSONObject(Http.getAny(spot, "/api/v3/depth?symbol=$sym&limit=100"))
            val bids = o.getJSONArray("bids")
            val asks = o.getJSONArray("asks")
            if (bids.length() == 0 || asks.length() == 0) return
            val bestBid = bids.getJSONArray(0).getString(0).toDouble()
            val bestAsk = asks.getJSONArray(0).getString(0).toDouble()
            val mid = (bestBid + bestAsk) / 2.0
            val lowBid = bids.getJSONArray(bids.length() - 1).getString(0).toDouble()
            val highAsk = asks.getJSONArray(asks.length() - 1).getString(0).toDouble()
            // берём одинаковый диапазон цен вокруг середины с обеих сторон
            val d = minOf(mid - lowBid, highAsk - mid)
            var bidSum = 0.0
            var askSum = 0.0
            for (i in 0 until bids.length()) {
                val b = bids.getJSONArray(i)
                val p = b.getString(0).toDouble()
                if (p >= mid - d) bidSum += p * b.getString(1).toDouble()
            }
            for (i in 0 until asks.length()) {
                val a = asks.getJSONArray(i)
                val p = a.getString(0).toDouble()
                if (p <= mid + d) askSum += p * a.getString(1).toDouble()
            }
            if (sym != lastSym) return
            if (bidSum + askSum > 0.0) bookBuy = bidSum / (bidSum + askSum)
            bookNote = ""
        } catch (e: Exception) {
            bookNote = "стакан: " + (e.message ?: "ошибка")
        }
    }

    private fun refreshFutures(sym: String) {
        try {
            val g = JSONArray(Http.get("$FUT/futures/data/globalLongShortAccountRatio?symbol=$sym&period=5m&limit=1"))
            if (g.length() > 0 && sym == lastSym) allLong = g.getJSONObject(0).getString("longAccount").toDouble()
            val t = JSONArray(Http.get("$FUT/futures/data/topLongShortPositionRatio?symbol=$sym&period=5m&limit=1"))
            if (t.length() > 0 && sym == lastSym) topLong = t.getJSONObject(0).getString("longAccount").toDouble()
            val pi = JSONObject(Http.get("$FUT/fapi/v1/premiumIndex?symbol=$sym"))
            if (sym == lastSym) funding = pi.getString("lastFundingRate").toDouble() * 100.0
            val oi = JSONObject(Http.get("$FUT/fapi/v1/openInterest?symbol=$sym"))
            if (sym == lastSym) openInterest = oi.getString("openInterest").toDouble()
            futuresNote = ""
        } catch (e: Exception) {
            futuresNote = "нет данных фьючерсов (" + (e.message ?: "ошибка") + ")"
        }
    }
}
