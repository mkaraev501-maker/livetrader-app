package com.livetrader

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun fmtPrice(v: Double): String =
    if (v >= 100.0) String.format(Locale.US, "%.2f", v)
    else if (v >= 1.0) String.format(Locale.US, "%.4f", v)
    else String.format(Locale.US, "%.6f", v)

fun fmtSigned(v: Double): String =
    (if (v >= 0.0) "+" else "") + String.format(Locale.US, "%.2f", v)

data class Position(
    val side: String,       // BUY или SELL
    val symbol: String,
    val entry: Double,
    val size: Double,       // размер в USDT
    val slPrice: Double,
    val tpPrice: Double     // 0 = без тейка
)

data class Proposal(
    val side: String,
    val symbol: String,
    val slPct: Double,
    val tpPct: Double,
    val reason: String
)

/** Виртуальный счёт: настоящих денег и настоящих ордеров здесь нет. */
object Paper {
    private const val START_BALANCE = 10000.0
    private const val FEE = 0.001   // 0.1% за сторону, как на споте Binance

    private var prefs: SharedPreferences? = null
    @Volatile var balance: Double = START_BALANCE
    @Volatile var pos: Position? = null
    @Volatile var proposal: Proposal? = null
    private var trades = JSONArray()

    @Synchronized
    fun init(c: Context) {
        if (prefs != null) return
        val p = c.applicationContext.getSharedPreferences("paper", Context.MODE_PRIVATE)
        prefs = p
        balance = p.getString("balance", null)?.toDoubleOrNull() ?: START_BALANCE
        trades = try {
            JSONArray(p.getString("trades", "[]"))
        } catch (e: Exception) {
            JSONArray()
        }
        pos = try {
            val s = p.getString("pos", null)
            if (s == null) null else posFromJson(JSONObject(s))
        } catch (e: Exception) {
            null
        }
    }

    private fun posToJson(p: Position): JSONObject {
        val j = JSONObject()
        j.put("side", p.side)
        j.put("symbol", p.symbol)
        j.put("entry", p.entry)
        j.put("size", p.size)
        j.put("sl", p.slPrice)
        j.put("tp", p.tpPrice)
        return j
    }

    private fun posFromJson(j: JSONObject): Position =
        Position(
            j.getString("side"), j.getString("symbol"), j.getDouble("entry"),
            j.getDouble("size"), j.getDouble("sl"), j.getDouble("tp")
        )

    private fun save() {
        val p = prefs ?: return
        val e = p.edit()
        e.putString("balance", balance.toString())
        e.putString("trades", trades.toString())
        val ps = pos
        if (ps == null) e.remove("pos") else e.putString("pos", posToJson(ps).toString())
        e.apply()
    }

    /** Открыть учебную позицию. Возвращает текст ошибки или null. */
    @Synchronized
    fun open(side: String, symbol: String, price: Double, size: Double, slPct: Double, tpPct: Double): String? {
        if (pos != null) return "Уже есть открытая позиция"
        if (size < 10.0) return "Минимальный размер 10 USDT"
        if (size > balance) return "Размер больше баланса"
        if (slPct <= 0.0) return "Стоп-лосс обязателен"
        val buy = side == "BUY"
        val sl = if (buy) price * (1.0 - slPct / 100.0) else price * (1.0 + slPct / 100.0)
        val tp = if (tpPct <= 0.0) 0.0 else if (buy) price * (1.0 + tpPct / 100.0) else price * (1.0 - tpPct / 100.0)
        pos = Position(side, symbol, price, size, sl, tp)
        proposal = null
        save()
        Bus.line(
            "Открыто: " + (if (buy) "ВВЕРХ " else "ВНИЗ ") + symbol + " по " + fmtPrice(price) +
                ", размер " + fmtPrice(size) + " USDT, стоп " + fmtPrice(sl)
        )
        return null
    }

    fun unrealized(p: Position, price: Double): Double {
        val gross = if (p.side == "BUY") p.size * (price / p.entry - 1.0) else p.size * (1.0 - price / p.entry)
        return gross - p.size * FEE * 2.0
    }

    @Synchronized
    fun close(price: Double, why: String) {
        val p = pos ?: return
        val pnl = unrealized(p, price)
        balance += pnl
        val t = JSONObject()
        t.put("time", SimpleDateFormat("dd.MM HH:mm", Locale.US).format(Date()))
        t.put("symbol", p.symbol)
        t.put("side", p.side)
        t.put("entry", p.entry)
        t.put("exit", price)
        t.put("size", p.size)
        t.put("pnl", pnl)
        t.put("why", why)
        trades.put(t)
        if (trades.length() > 300) {
            val n = JSONArray()
            for (i in trades.length() - 300 until trades.length()) n.put(trades.get(i))
            trades = n
        }
        pos = null
        save()
        Bus.line("Закрыто (" + why + ") " + p.symbol + ": " + fmtSigned(pnl) + " USDT")
    }

    /** Проверка стопа и тейка на каждом тике цены. */
    @Synchronized
    fun onPrice(symbol: String, price: Double) {
        val p = pos ?: return
        if (p.symbol != symbol) return
        if (p.side == "BUY") {
            if (price <= p.slPrice) close(price, "стоп")
            else if (p.tpPrice > 0.0 && price >= p.tpPrice) close(price, "тейк")
        } else {
            if (price >= p.slPrice) close(price, "стоп")
            else if (p.tpPrice > 0.0 && price <= p.tpPrice) close(price, "тейк")
        }
    }

    fun setProposal(p: Proposal) {
        proposal = p
        Bus.line(
            "Помощник предлагает: " + (if (p.side == "BUY") "ВВЕРХ " else "ВНИЗ ") + p.symbol +
                ", стоп " + p.slPct + "%, тейк " + p.tpPct + "%. " + p.reason
        )
    }

    fun clearProposal() {
        proposal = null
        Bus.ping()
    }

    @Synchronized
    fun reset() {
        balance = START_BALANCE
        trades = JSONArray()
        pos = null
        proposal = null
        save()
        Bus.line("Счёт сброшен: 10000 USDT.")
    }

    @Synchronized
    fun statsText(): String {
        var n = 0
        var w = 0
        var total = 0.0
        for (i in 0 until trades.length()) {
            val pn = trades.getJSONObject(i).optDouble("pnl", 0.0)
            n++
            total += pn
            if (pn > 0.0) w++
        }
        val rate = if (n > 0) w * 100 / n else 0
        return "Сделок: $n, плюс: $w ($rate%), итог: " + fmtSigned(total) + " USDT"
    }
}
